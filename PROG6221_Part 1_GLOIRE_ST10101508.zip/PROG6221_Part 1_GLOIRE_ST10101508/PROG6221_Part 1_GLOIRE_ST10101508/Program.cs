﻿// See https://aka.ms/new-console-template for more information
using PROG6221_POE_GLOIRE_ST10101508;
using System;

class Program
{
    static void Main(string[] args)
    {

        Recipe recipe = new Recipe();
        while (true)
        {
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("Welcome To The Recipe App");
            Console.WriteLine("*************************");
            Console.WriteLine("");
            Console.WriteLine("Enter '1' to enter recipe details");
            Console.WriteLine("Enter '2' to display recipe");
            Console.WriteLine("Enter '3' to scale recipe");
            Console.WriteLine("Enter '4' to reset quantities");
            Console.WriteLine("Enter '5' to clear recipe");
            Console.WriteLine("Enter '6' to exit");
            Console.WriteLine("");
            string choice = Console.ReadLine();
            switch (choice)
            {

                case "1":
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.White;
                    recipe.EnterDetails();
                    break;
                case "2":
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    recipe.DisplayRecipe();
                    break;
                case "3":
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    recipe.ScaleRecipe(factor);
                    break;
                case "4":
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine("");
                    recipe.ResetQuantities();
                    break;
                case "5":
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("");
                    recipe.ClearRecipe();
                    break;
                case "6":
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("");
                    Console.WriteLine("Exiting program...");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please enter a valid choice.");
                    break;
            }
        }
    }
}