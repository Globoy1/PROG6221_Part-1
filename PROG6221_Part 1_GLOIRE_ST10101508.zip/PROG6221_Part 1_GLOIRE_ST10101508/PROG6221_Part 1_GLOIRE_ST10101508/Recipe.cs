﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6221_POE_GLOIRE_ST10101508
{
    internal class Recipe
    {
        public string[] ingredients;
        public double[] quantities;
        public string[] unitofmeasurement;
        public string[] steps;
        public double[] orginalvalue;
        public Recipe()
        {
            ingredients = new string[0];
            quantities = new double[0];
            unitofmeasurement = new string[0];
            steps = new string[0]; 
        }
        public void EnterDetails()
        {
            // Prompt the user to enter the number of ingredients
            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Initialize the arrays with the correct size
            ingredients = new string[numIngredients];
            quantities = new double[numIngredients];
            unitofmeasurement = new string[numIngredients];
            orginalvalue = new double[numIngredients];

            // Prompt the user to enter the details for each ingredient
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter details for ingredient #{i + 1}:");
                Console.Write("Name: ");
                ingredients[i] = Console.ReadLine();
                Console.Write("Quantity: ");
                quantities[i] = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                unitofmeasurement[i] = Console.ReadLine();
            }
            // Prompt the user to enter the number of steps
            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Initialize the steps array with the correct size
            steps = new string[numSteps];

            // Prompt the user to enter the details for each step
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step #{i + 1}: ");
                steps[i] = Console.ReadLine();
            }

        }
        public void DisplayRecipe()
        {
            // Display the ingredients and quantities
            Console.WriteLine("The list of ingredients and steps are bellow:");
            Console.WriteLine("");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"- {quantities[i]} {unitofmeasurement[i]} of {ingredients[i]}");
            }
            Console.WriteLine("");
            // Display the steps
            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"- {steps[i]}");
            }
        }
        public void ScaleRecipe(double factor)
        {
           
            // Multiply all the quantities by the scaling factor
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= factor;
            }
        }

        public void ResetQuantities()
        {

            //Reset all the quantities to their original values
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] /= 2;
                Console.WriteLine("All ingredient and step reset to normal value");
            }
        }

        public void ClearRecipe()
        {
            Console.WriteLine("Select 'yes' to clear up...");
            Console.WriteLine("Select 'no' to not clear up...");
            String clear = Console.ReadLine();

            // Conditional statements are used to perform different actions based on different conditions followed below.

            if (clear == "yes")
            {
                // Reset all the arrays to empty
                ingredients = new string[0];
                quantities = new double[0];
                unitofmeasurement = new string[0];
                steps = new string[0];
                Console.WriteLine("All ingredient cleared");
            }
            else if (clear == "no")
            {
                Console.WriteLine("You did not clear the ingredient");
            }
            else
            {
                Console.WriteLine("You did not select 'yes' or 'No'");
            }

        }

    }
}